from pythonWordArt.main import pyWordArt
